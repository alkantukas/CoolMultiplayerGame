import pygame
import time
import pyperclip
pygame.init()

def clamp(num, min_value, max_value):
   return max(min(num, max_value), min_value)

class Button:
    def __init__(self, Position, Offset, Size, Text, Colour, TextColour, Font, FontSize):
        self.rect = pygame.Rect(0, 0, *Size)
        self.position = Position
        self.offset = Offset
        self.text = Text
        self.colour = Colour
        self.textColour = TextColour
        self.font = pygame.font.Font(Font, FontSize)
        self.fontSize = FontSize
        self.active = True
        self.renderText()

    def renderText(self):
        self.textSurface = self.font.render(self.text, True, self.textColour)
        self.textRect = self.textSurface.get_rect()

    def clicked(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.active:
            if self.rect.collidepoint(pygame.mouse.get_pos()):
                return True
        return False

    def draw(self, screen):
        self.renderText()
        screenSize = screen.get_size()

        pos = (screenSize[0]*self.position[0]+self.offset[0] , screenSize[1]*self.position[1]+self.offset[1])
        self.rect.center = pos
        self.textRect.center = self.rect.center

        colour = self.colour
        if self.rect.collidepoint(pygame.mouse.get_pos()) and self.active:
            colour = (clamp(self.colour[0]-50, 0, 255), clamp(self.colour[1]-50, 0, 255), clamp(self.colour[2]-50, 0, 255))

        if self.colour != ():
            pygame.draw.rect(screen, colour, self.rect)

        screen.blit(self.textSurface, self.textRect)


class TextBox:
    def __init__(self, Position, Offset, Size, PlaceholderText, Colour, TextColour, Font, FontSize, CharacterLimit):
        self.rect = pygame.Rect(0, 0, *Size)
        self.position = Position
        self.offset = Offset
        self.text = ''
        self.placeholderText = PlaceholderText
        self.colour = Colour
        self.textColour = TextColour
        self.font = pygame.font.Font(Font, FontSize)
        self.fontSize = FontSize
        self.active = True
        self.selected = False
        self.charLimit = CharacterLimit
        self.lastPaste = 0
        self.renderPlaceholder()

    def input(self, event):
        if self.selected and event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_BACKSPACE:
                self.text = self.text[0:-1]
            elif event.key == pygame.K_RETURN:
                self.selected = False
            else:
                if len(self.text) < self.charLimit:
                    self.text += event.unicode
            
            #Pasting
            if time.time() - self.lastPaste >= 0.05:
                vDown, ctrlDown = False, False

                keys = pygame.key.get_pressed()
                if keys[pygame.K_v] and keys[pygame.K_LCTRL]:
                    self.text = self.text[0:-1]
                    self.text += pyperclip.paste()

        #Selecting
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.active:
            if self.rect.collidepoint(pygame.mouse.get_pos()):
                self.selected = True
            else:
                self.selected = False

    def renderPlaceholder(self):
        placeholderC = (clamp(self.textColour[0]-50, 0, 255), clamp(self.textColour[1]-50, 0, 255), clamp(self.textColour[2]-50, 0, 255))
        self.placeholderSurface = self.font.render(self.placeholderText, True, placeholderC)
        self.placeholderRect = self.placeholderSurface.get_rect()

    def draw(self, screen):
        screenSize = screen.get_size()

        pos = (screenSize[0]*self.position[0]+self.offset[0] , screenSize[1]*self.position[1]+self.offset[1])
        self.rect.center = pos
        self.placeholderRect.center = self.rect.center
    
        if self.colour != ():
            pygame.draw.rect(screen, self.colour, self.rect)

        if self.text == '' and not self.selected:
            screen.blit(self.placeholderSurface, self.placeholderRect)
        else:
            textSurface = self.font.render(self.text, True, self.textColour)
            textRect = textSurface.get_rect()
            
            textRect.center = self.rect.center
            textRect.left = self.rect.left

            screen.blit(textSurface, textRect)

class Text:
    def __init__(self, Position, Offset, Size, Text, Colour, TextColour, Font, FontSize):
        self.rect = pygame.Rect(0, 0, *Size)
        self.position = Position
        self.offset = Offset
        self.text = Text
        self.colour = Colour
        self.textColour = TextColour
        self.font = pygame.font.Font(Font, FontSize)
        self.fontSize = FontSize
        self.renderText()

    def renderText(self):
        self.textSurface = self.font.render(self.text, True, self.textColour)
        self.textRect = self.textSurface.get_rect()

    def draw(self, screen):
        self.renderText()
        screenSize = screen.get_size()

        pos = (screenSize[0]*self.position[0]+self.offset[0] , screenSize[1]*self.position[1]+self.offset[1])
        self.rect.center = pos
        self.textRect.center = self.rect.center

        if self.colour != ():
            pygame.draw.rect(screen, self.colour, self.rect)

        screen.blit(self.textSurface, self.textRect)

