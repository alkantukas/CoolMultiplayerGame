import pygame
import network
import json
import time
import math
import start
import easyUI

pygame.init()

#Images
grassImg = pygame.image.load('Tiles/grass.png')
grassImg = pygame.transform.scale(grassImg, (64,64))
dirtImg = pygame.image.load('Tiles/dirt.png')
plrImg = pygame.image.load('player.png')
plrImg = pygame.transform.scale(plrImg, (40,64))

#Display
pygame.display.set_caption('Game')
pygame.display.set_icon(plrImg)
screen = pygame.display.set_mode((0,0), pygame.RESIZABLE)

#Variables
cam = [0,0]
font = pygame.font.Font('Roboto-Bold.ttf', 16)

#UI
pingText = easyUI.Text((0,0), (40,10), (50,20), 'ping: ', (), (212, 156, 15), 'Roboto-Bold.ttf', 16)


def getPressed():
    key_numbers = []
    for key, value in enumerate(pygame.key.get_pressed()):
        if value:
            key_numbers.append(key)
    return key_numbers


def drawPlayer(player, showName):
    pos, name = player[0], player[1]

    newPos = (pos[0]+cam[0], pos[1]+cam[1])
    screen.blit(plrImg, newPos)

    if showName:
        text = font.render(name, True, (255,255,255))
        textRect = text.get_rect()
        textRect.center = (newPos[0]+32, newPos[1] - (textRect.height+5))

        screen.blit(text, textRect)
        

last = time.time()
def update(players, plrId, ping):
    global cam, last
    screen.fill((146,244,255))

    screenSize = screen.get_size()
    dt = time.time() - last
    last = time.time()

    #Draw players
    for id, player in players.items():
        showName = True
        if int(plrId) == int(id):
            showName = False
            cam[0] = screenSize[0]/2 - plrImg.get_width()/2 - player[0][0]
            cam[1] = screenSize[1]/2 - plrImg.get_height()/2 - player[0][1]

        drawPlayer(player, showName)

    #Draw map
    for x in range(0, math.ceil(screen.get_size()[0]/64)):
        pos = (x*64+int(cam[0]-screenSize[0]/2), 500+int(cam[1]))

        screen.blit(grassImg, pos)


    #Display ping
    pingText.text = 'ping: '+str(int(ping))+'ms'
    pingText.draw(screen)


    pygame.display.update()


def main(n, plrId):
    running = True

    while running:
        start = time.time()
        data = n.send(getPressed())
        ping = time.time() - start

        players = json.loads(data)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        update(players, plrId, ping)

    pygame.quit()


try:
    n, plrId = start.main(screen)
    main(n, plrId)
except:
    pass
