import pygame
import easyUI
import network
import time
pygame.init()

joinButton = easyUI.Button((0.5,0.5), (0,0), (300, 75), 'Join', (125, 125, 125), (255,255,255), 'Roboto-Bold.ttf', 26)
addrInput = easyUI.TextBox((0.5,0.5), (0,-100), (300, 75), 'Address', (125, 125, 125), (255,255,255), 'Roboto-Bold.ttf', 26, 100)
usernameInput = easyUI.TextBox((0.5,0.5), (0,-200), (300, 75), 'Username', (125, 125, 125), (255,255,255), 'Roboto-Bold.ttf', 26, 20)
errorText = easyUI.Text((0.5,0.5), (0,75), (300, 50), 'error', (), (255,0,0), 'Roboto-Bold.ttf', 26)

errorVisible = 0


def main(screen):
    global errorVisible

    running = True

    while running:
        screen.fill((146,244,255))

        joinButton.draw(screen)
        addrInput.draw(screen)
        usernameInput.draw(screen)

        if time.time() - errorVisible <= 3:
            errorText.draw(screen)

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if joinButton.clicked(event):
                if addrInput.text != '' and usernameInput.text != '':
                    parts = addrInput.text.split(':')

                    if len(parts) == 2:
                        ip, port = parts[0], parts[1]

                        n = network.Network(ip, int(port))
                        e = n.connect(usernameInput.text)

                        if e == 'error':
                            errorText.text = 'Failed to connect'
                            errorVisible = time.time()
                            print(e)
                        else:
                            print('connect')
                            return [n, e]
                    else:
                        errorText.text = 'Invalid address'
                        errorVisible = time.time()
                else:
                    if addrInput.text == '':
                        errorText.text = "Address field can't be empty"
                        errorVisible = time.time()
                    if usernameInput.text == '':
                        errorText.text = "Username field can't be empty"
                        errorVisible = time.time()
            
            addrInput.input(event)
            usernameInput.input(event)

    pygame.quit()
