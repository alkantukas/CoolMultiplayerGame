import socket
import json

class Network:
    def __init__(self, ip, port):
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server = ip
        self.port = port
        self.addr = (self.server, self.port)

    def connect(self, username):
        try:
            self.client.connect(self.addr)

            #Send username
            dataJson = json.dumps(username)
            dataBytes = dataJson.encode()
            self.client.send(dataBytes)
            
            #Get ID
            return self.client.recv(8).decode()
        except:
            return 'error'

    def send(self, data):
        try:
            dataJson = json.dumps(data)
            dataBytes = dataJson.encode()

            self.client.send(dataBytes)
            return self.client.recv(2048).decode()
        except socket.error as e:
            print(e)

