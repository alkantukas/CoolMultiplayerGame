import socket
import json
import time
from _thread import start_new_thread
import sys

server = "192.168.8.104"
port = 5555

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    s.bind((server, port))
except socket.error as e:
    str(e)

s.listen(10) # Max players
print('Server started')

players = {}
plrSpeed = 400
jumpPower = 1000
gravity = 10
ground = 500


def move(keys, plr, yVel, dt):
    pos = plr[0]

    # Gravity
    yVel += gravity

    # Clamp position and remove downwards force if touching ground
    grounded = False
    if pos[1] >= ground-64:  # 50 is players height
        pos[1] = ground-64
        yVel = 0
        grounded = True

    for key in keys:
        if key == 4:  # A
            pos[0] -= plrSpeed * dt
        if key == 7:  # D
            pos[0] += plrSpeed * dt
        if key == 44 or key == 26:  # 44 is space, 26 is W
            if grounded:  # Only jump if player is grounded
                yVel -= jumpPower

    # Apply downwards force
    pos[1] += yVel * dt

    return yVel


def threadedClient(conn):
    username = conn.recv(32)
    username = json.loads(username)
    print(username + ' connected')

    playerId = len(players)+1
    conn.send(str.encode(str(playerId)))

    players[playerId] = [[0, 0], username]  # Position, name

    yVel = 0
    last = time.time()
    while True:
        try:
            data = conn.recv(2048)
            reply = json.loads(data)

            if not data:
                # Disconnected
                break
            else:
                dt = time.time() - last
                last = time.time()

                yVel = move(reply, players[playerId], yVel, dt)

            # Send data
            playersJson = json.dumps(players)
            playersBytes = playersJson.encode()

            conn.sendall(playersBytes)
        except:
            break
    
    # Lost connection
    del players[playerId]

    conn.close()


while True:
    conn, addr = s.accept()
    # Connected

    start_new_thread(threadedClient, (conn,))
